const MODULE_ID = "sra2-turn-checkbox";
const FLAG_TURN_TAKEN = "turnTaken";
const FLAG_SLOT_CLAIMED = "slotClaimed";
const RELAY_MAKE_ACTIVE_TURN = "makeActiveTurn";
const RELAY_SET_TURN_TAKEN = "setTurnTaken";
const RELAY_CLAIM_ACTIVE_TURN = "claimActiveTurn";
const RELAY_FLAG = "gmRelayRequest";
const processedRelayRequestIds = new Set();

const COMBATANT_ROW_SELECTOR = [
  "li.combatant[data-combatant-id]",
  "div.combatant[data-combatant-id]",
  "article.combatant[data-combatant-id]",
  "li[data-combatant-id]",
  "div[data-combatant-id]",
  "article[data-combatant-id]"
].join(",");

const INITIATIVE_BUTTON_SELECTOR = [
  "[data-action='rollInitiative']",
  "[data-control='rollInitiative']",
  ".combatant-control[data-action='rollInitiative']",
  ".combatant-control[data-control='rollInitiative']",
  ".roll-initiative",
  ".initiative .roll",
  ".initiative button[title*='Initiative' i]",
  ".initiative a[title*='Initiative' i]",
  "button[aria-label*='Initiative' i]",
  "a[aria-label*='Initiative' i]"
].join(",");

function isSra2World() {
  return game?.system?.id === "sra2";
}

function htmlElementFromRenderHook(html) {
  if (html instanceof HTMLElement) return html;
  if (html?.[0] instanceof HTMLElement) return html[0];
  if (html?.element instanceof HTMLElement) return html.element;
  return null;
}

function getViewedCombat(app) {
  return app?.viewed ?? app?.combat ?? game?.combat ?? null;
}

function getCombatantForRow(combat, row) {
  const id = row?.dataset?.combatantId ?? row?.getAttribute?.("data-combatant-id");
  if (!id) return null;
  return combat?.combatants?.get?.(id) ?? null;
}

function isCombatantClaimed(combatant) {
  return Boolean(combatant?.getFlag?.(MODULE_ID, FLAG_SLOT_CLAIMED));
}

function combatantCanBeChecked(combatant) {
  // Any connected player should be able to mark any combatant as having taken
  // a turn. Non-GM clients ask an active GM client to apply the Combatant flag
  // because players generally cannot edit Combatant documents they do not own.
  return Boolean(combatant?.combat);
}

function combatantCanBeMadeActive(combatant) {
  // Let players click the hand button too. Non-GM clients ask an active GM
  // client to perform the Combat document update through a GM relay message.
  return Boolean(combatant?.combat);
}

function getCombatantTurnIndex(combat, combatant) {
  if (!combat || !combatant) return -1;

  const turns = Array.from(combat.turns ?? []);
  let index = turns.findIndex(turn => turn?.id === combatant.id);
  if (index >= 0) return index;

  // Fallback for trackers or systems that have not populated combat.turns yet.
  const combatants = Array.from(combat.combatants ?? []);
  return combatants.findIndex(candidate => candidate?.id === combatant.id);
}

async function updateCombatActiveTurn(combat, combatant) {
  const turnIndex = getCombatantTurnIndex(combat, combatant);
  if (turnIndex < 0) {
    ui.notifications?.warn(`Unable to find ${combatant?.name ?? "that combatant"} in the current encounter order.`);
    return false;
  }

  await combat.update({ turn: turnIndex });
  return true;
}

async function updateCombatantClaimed(combatant, value) {
  await combatant.setFlag(MODULE_ID, FLAG_SLOT_CLAIMED, Boolean(value));
  return true;
}

async function claimCombatantAndMakeActiveTurn(combat, combatant) {
  if (!combat || !combatant) return false;

  await updateCombatantClaimed(combatant, true);
  return updateCombatActiveTurn(combat, combatant);
}

function getActiveGmUser() {
  const activeGms = Array.from(game.users ?? [])
    .filter(user => user?.active && user?.isGM)
    .sort((a, b) => String(a.id).localeCompare(String(b.id)));

  return activeGms[0] ?? null;
}

function getRelayRequestId() {
  if (globalThis.foundry?.utils?.randomID) return foundry.utils.randomID();
  if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function getGmWhisperRecipientIds() {
  const gmRecipients = globalThis.ChatMessage?.getWhisperRecipients?.("GM") ?? [];
  const ids = gmRecipients.map(user => user?.id).filter(Boolean);

  if (ids.length) return ids;

  return Array.from(game.users ?? [])
    .filter(user => user?.isGM)
    .map(user => user.id)
    .filter(Boolean);
}

async function createGmRelayMessage(payload) {
  const whisper = getGmWhisperRecipientIds();
  const requestId = getRelayRequestId();

  await ChatMessage.create({
    user: game.user?.id,
    speaker: ChatMessage.getSpeaker?.() ?? {},
    content: `<p class="sra2tc-relay-message">SRA2 combat tracker player action relay.</p>`,
    whisper,
    blind: true,
    flags: {
      [MODULE_ID]: {
        [RELAY_FLAG]: {
          ...payload,
          requestId,
          requesterId: game.user?.id ?? null,
          createdAt: Date.now()
        }
      }
    }
  }, { chatBubble: false });

  return true;
}

async function emitGmRequest(payload, warningMessage) {
  const activeGm = getActiveGmUser();
  if (!activeGm) {
    ui.notifications?.warn(warningMessage);
    return false;
  }

  try {
    return await createGmRelayMessage(payload);
  } catch (error) {
    console.error(`${MODULE_ID} | Failed to create GM relay message`, error);
    ui.notifications?.error("Unable to send that combat tracker action to the GM client.");
    return false;
  }
}

async function requestGmClaimActiveTurn(combat, combatant) {
  return emitGmRequest({
    action: RELAY_CLAIM_ACTIVE_TURN,
    combatId: combat.id,
    combatantId: combatant.id,
    sceneId: combat.scene?.id ?? combat.sceneId ?? null
  }, "A GM must be connected before a player can claim a combat slot.");
}

async function requestGmMakeActiveTurn(combat, combatant) {
  return emitGmRequest({
    action: RELAY_MAKE_ACTIVE_TURN,
    combatId: combat.id,
    combatantId: combatant.id,
    sceneId: combat.scene?.id ?? combat.sceneId ?? null
  }, "A GM must be connected before a player can change the active combat turn.");
}

async function updateCombatantTurnTaken(combatant, value) {
  await combatant.setFlag(MODULE_ID, FLAG_TURN_TAKEN, value);
  return true;
}

async function requestGmSetTurnTaken(combatant, value) {
  return emitGmRequest({
    action: RELAY_SET_TURN_TAKEN,
    combatId: combatant.combat?.id ?? null,
    combatantId: combatant.id,
    sceneId: combatant.combat?.scene?.id ?? combatant.combat?.sceneId ?? null,
    value: Boolean(value)
  }, "A GM must be connected before a player can mark another combatant's turn checkbox.");
}

async function setCombatantTurnTaken(combatant, value) {
  if (!combatant) return false;

  if (game.user?.isGM) {
    return updateCombatantTurnTaken(combatant, value);
  }

  return requestGmSetTurnTaken(combatant, value);
}

async function makeCombatantActiveTurn(combat, combatant) {
  if (!combat || !combatant) return false;

  if (game.user?.isGM) {
    return updateCombatActiveTurn(combat, combatant);
  }

  return requestGmMakeActiveTurn(combat, combatant);
}

async function claimAndMakeCombatantActiveTurn(combat, combatant) {
  if (!combat || !combatant) return false;

  if (game.user?.isGM) {
    return claimCombatantAndMakeActiveTurn(combat, combatant);
  }

  return requestGmClaimActiveTurn(combat, combatant);
}

async function processGmRelayRequest(message) {
  if (!isSra2World()) return;
  if (!game.user?.isGM) return;

  // Avoid duplicate updates when more than one GM is connected. Only the first
  // active GM client handles player requests.
  if (getActiveGmUser()?.id !== game.user?.id) return;

  const relay = message?.getFlag?.(MODULE_ID, RELAY_FLAG);
  if (!relay || typeof relay !== "object") return;
  if (![RELAY_MAKE_ACTIVE_TURN, RELAY_SET_TURN_TAKEN, RELAY_CLAIM_ACTIVE_TURN].includes(relay.action)) return;

  const requestId = relay.requestId ?? message.id;
  if (processedRelayRequestIds.has(requestId)) return;
  processedRelayRequestIds.add(requestId);

  try {
    const combat = game.combats?.get?.(relay.combatId);
    const combatant = combat?.combatants?.get?.(relay.combatantId);

    if (!combat || !combatant) {
      console.warn(`${MODULE_ID} | Ignoring relay request for an unavailable combatant`, relay);
      return;
    }

    if (relay.action === RELAY_MAKE_ACTIVE_TURN) {
      await updateCombatActiveTurn(combat, combatant);
    } else if (relay.action === RELAY_CLAIM_ACTIVE_TURN) {
      await claimCombatantAndMakeActiveTurn(combat, combatant);
    } else if (relay.action === RELAY_SET_TURN_TAKEN) {
      await updateCombatantTurnTaken(combatant, Boolean(relay.value));
    }
  } catch (error) {
    console.error(`${MODULE_ID} | Failed to process GM relay request`, error);
  } finally {
    try {
      // Keep the GM chat log clean. This message is blind-whispered to GMs only,
      // and is used only as a document-based relay for player actions.
      if (message?.id) await message.delete();
    } catch (error) {
      console.warn(`${MODULE_ID} | Could not delete relay chat message`, error);
    }
  }
}

function hideInitiativeButtons(row) {
  if (!game.settings.get(MODULE_ID, "hideInitiativeButtons")) return;

  for (const control of row.querySelectorAll(INITIATIVE_BUTTON_SELECTOR)) {
    // Only hide row-level combatant initiative controls. The hook scopes the search to
    // a combatant row so the header/global initiative controls remain untouched.
    control.classList.add("sra2tc-hidden-initiative-control");
    control.setAttribute("aria-hidden", "true");
    control.setAttribute("tabindex", "-1");
  }
}

function addMakeTurnButton(row, combat, combatant) {
  if (!combatant || row.querySelector(".sra2tc-make-turn")) return;

  const claimed = isCombatantClaimed(combatant);
  const disabled = !combatantCanBeMadeActive(combatant);
  const isActive = combat?.combatant?.id === combatant.id;
  const disableBecauseAlreadyClaimedActive = isActive && claimed;

  const button = document.createElement("button");
  button.type = "button";
  button.className = "sra2tc-make-turn";
  button.dataset.sra2tcCombatantId = combatant.id;
  button.disabled = disabled || disableBecauseAlreadyClaimedActive;
  button.title = disabled
    ? "This combatant cannot claim the active turn."
    : disableBecauseAlreadyClaimedActive
      ? `${combatant.name} is already claimed and active.`
      : claimed
        ? `Make ${combatant.name} the active turn.`
        : `Claim ${combatant.name}'s slot and make it the active turn.`;
  button.setAttribute("aria-label", claimed ? `Make ${combatant.name} the active turn` : `Claim ${combatant.name}'s slot`);
  button.classList.toggle("sra2tc-active-turn", isActive);

  const icon = document.createElement("i");
  icon.className = "fas fa-hand-paper";
  icon.setAttribute("aria-hidden", "true");

  const sr = document.createElement("span");
  sr.className = "sr-only";
  sr.textContent = claimed ? "Make active turn" : "Claim slot and make active turn";

  button.append(icon, sr);

  for (const eventName of ["click", "mousedown", "mouseup", "pointerdown", "pointerup"]) {
    button.addEventListener(eventName, event => event.stopPropagation());
  }

  button.addEventListener("click", async event => {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    if (button.disabled) return;

    const previousDisabled = button.disabled;
    button.disabled = true;

    try {
      const requested = claimed
        ? await makeCombatantActiveTurn(combat, combatant)
        : await claimAndMakeCombatantActiveTurn(combat, combatant);
      if (!requested) button.disabled = previousDisabled;
    } catch (error) {
      console.error(`${MODULE_ID} | Failed to claim or make combatant the active turn`, error);
      ui.notifications?.error(`Unable to claim ${combatant.name}'s slot.`);
      button.disabled = previousDisabled;
    }
  });

  const checkbox = row.querySelector(".sra2tc-turn-check");
  const insertionPoint = checkbox?.nextSibling ?? row.querySelector("img, .combatant-image, .token-image, .portrait") ?? row.firstElementChild;
  if (insertionPoint) row.insertBefore(button, insertionPoint);
  else row.prepend(button);
}

function addTurnCheckbox(row, combatant) {
  if (!combatant || row.querySelector(".sra2tc-turn-check")) return;

  const checked = Boolean(combatant.getFlag(MODULE_ID, FLAG_TURN_TAKEN));
  const disabled = !combatantCanBeChecked(combatant);

  row.classList.toggle("sra2tc-turn-taken", checked);

  const label = document.createElement("label");
  label.className = "sra2tc-turn-check";
  label.title = disabled
    ? "This combatant cannot be marked as having taken its turn."
    : "Mark whether this combatant has taken their turn this round.";

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.checked = checked;
  checkbox.disabled = disabled;
  checkbox.dataset.sra2tcCombatantId = combatant.id;
  checkbox.setAttribute("aria-label", `Turn taken: ${combatant.name}`);

  const visual = document.createElement("span");
  visual.className = "sra2tc-turn-check-box";
  visual.setAttribute("aria-hidden", "true");

  const sr = document.createElement("span");
  sr.className = "sr-only";
  sr.textContent = "Turn taken";

  label.append(checkbox, visual, sr);

  // Foundry v13's Combat Tracker listens for change events in the tracker. Stop
  // propagation so this checkbox is not interpreted as an initiative edit.
  for (const eventName of ["click", "mousedown", "mouseup", "pointerdown", "pointerup", "input"]) {
    label.addEventListener(eventName, event => event.stopPropagation());
    checkbox.addEventListener(eventName, event => event.stopPropagation());
  }

  checkbox.addEventListener("change", async event => {
    event.stopPropagation();
    event.stopImmediatePropagation();

    const desiredValue = checkbox.checked;
    row.classList.toggle("sra2tc-turn-taken", desiredValue);

    try {
      const requested = await setCombatantTurnTaken(combatant, desiredValue);
      if (!requested) {
        checkbox.checked = !desiredValue;
        row.classList.toggle("sra2tc-turn-taken", checkbox.checked);
      }
    } catch (error) {
      console.error(`${MODULE_ID} | Failed to update turn checkbox`, error);
      checkbox.checked = !desiredValue;
      row.classList.toggle("sra2tc-turn-taken", checkbox.checked);
      ui.notifications?.error("Unable to update that combatant's turn checkbox.");
    }
  });

  const insertionPoint = row.querySelector("img, .combatant-image, .token-image, .portrait") ?? row.firstElementChild;
  if (insertionPoint) row.insertBefore(label, insertionPoint);
  else row.prepend(label);
}

function createSectionHeader(tagName, label, count) {
  const safeTagName = String(tagName ?? "div").toUpperCase() === "LI" ? "li" : "div";
  const header = document.createElement(safeTagName);
  header.className = "sra2tc-section-header";
  header.dataset.sra2tcSectionHeader = label.toLowerCase();
  header.setAttribute("role", "separator");

  const title = document.createElement("span");
  title.className = "sra2tc-section-title";
  title.textContent = label;

  const countBadge = document.createElement("span");
  countBadge.className = "sra2tc-section-count";
  countBadge.textContent = String(count);
  countBadge.setAttribute("aria-label", `${count} ${label.toLowerCase()} combatants`);

  header.append(title, countBadge);
  return header;
}

function groupRowsByParent(rows) {
  const groups = new Map();

  for (const row of rows) {
    const parent = row?.parentElement;
    if (!parent) continue;
    if (!groups.has(parent)) groups.set(parent, []);
    groups.get(parent).push(row);
  }

  return groups;
}

function splitCombatantRows(root, combat, rows) {
  if (!game.settings.get(MODULE_ID, "splitClaimSections")) return;
  if (!root || !combat || !rows?.length) return;

  const groups = groupRowsByParent(rows);

  for (const [parent, groupedRows] of groups.entries()) {
    for (const existingHeader of Array.from(parent.children).filter(child => child?.classList?.contains("sra2tc-section-header"))) {
      existingHeader.remove();
    }

    const orderedRows = groupedRows.filter(row => row?.isConnected && row.parentElement === parent);
    if (!orderedRows.length) continue;

    const unclaimedRows = [];
    const claimedRows = [];

    for (const row of orderedRows) {
      const combatant = getCombatantForRow(combat, row);
      const claimed = isCombatantClaimed(combatant);
      row.classList.toggle("sra2tc-slot-claimed", claimed);
      row.classList.toggle("sra2tc-slot-unclaimed", !claimed);
      if (claimed) claimedRows.push(row);
      else unclaimedRows.push(row);
    }

    const marker = document.createComment("sra2tc-claimed-unclaimed-sections");
    parent.insertBefore(marker, orderedRows[0]);

    const fragment = document.createDocumentFragment();
    const headerTagName = orderedRows[0]?.tagName ?? "div";

    fragment.append(createSectionHeader(headerTagName, "Unclaimed", unclaimedRows.length));
    for (const row of unclaimedRows) fragment.append(row);

    fragment.append(createSectionHeader(headerTagName, "Claimed", claimedRows.length));
    for (const row of claimedRows) fragment.append(row);

    parent.insertBefore(fragment, marker);
    marker.remove();
  }
}

function patchCombatTracker(app, html) {
  if (!isSra2World()) return;

  const root = htmlElementFromRenderHook(html);
  if (!root) return;

  const combat = getViewedCombat(app);
  if (!combat) return;

  const rows = Array.from(root.querySelectorAll(COMBATANT_ROW_SELECTOR))
    .filter(row => row instanceof HTMLElement)
    .filter((row, index, all) => all.indexOf(row) === index)
    .filter(row => !row.classList.contains("sra2tc-section-header"));

  for (const row of rows) {
    const combatant = getCombatantForRow(combat, row);
    if (!combatant) continue;
    hideInitiativeButtons(row);
    addTurnCheckbox(row, combatant);
    addMakeTurnButton(row, combat, combatant);
  }

  splitCombatantRows(root, combat, rows);
}

async function clearRoundState(combat) {
  if (!combat?.combatants?.size) return;

  const combatants = Array.from(combat.combatants ?? []);
  const updates = combatants.map(combatant => ({
    _id: combatant.id,
    [`flags.${MODULE_ID}.${FLAG_TURN_TAKEN}`]: false,
    [`flags.${MODULE_ID}.${FLAG_SLOT_CLAIMED}`]: false
  }));

  if (updates.length) await combat.updateEmbeddedDocuments("Combatant", updates);
}

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "hideInitiativeButtons", {
    name: "Hide individual roll initiative buttons",
    hint: "Remove the roll initiative button from each combatant row in the Combat Encounters list. Header/global initiative controls are left alone.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });

  game.settings.register(MODULE_ID, "resetOnNewRound", {
    name: "Reset turn state on new round",
    hint: "Automatically clear every turn-taken checkbox and move every combatant back to Unclaimed when the combat round changes.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });

  game.settings.register(MODULE_ID, "splitClaimSections", {
    name: "Split combat tracker into Claimed and Unclaimed sections",
    hint: "Display Unclaimed combatants first and Claimed combatants second in the Combat Encounters list.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });
});

Hooks.on("createChatMessage", processGmRelayRequest);

Hooks.on("renderChatMessage", (message, html) => {
  if (!message?.getFlag?.(MODULE_ID, RELAY_FLAG)) return;

  const root = htmlElementFromRenderHook(html);
  if (root) root.style.display = "none";
});

Hooks.on("renderCombatTracker", patchCombatTracker);

Hooks.on("renderSidebarTab", (app, html, data, options) => {
  // Foundry v13 renders the combat tracker as an ApplicationV2 sidebar tab. Some
  // builds/modules reliably emit renderCombatTracker; this fallback catches the
  // generic sidebar render hook without affecting other tabs.
  if (app?.constructor?.name !== "CombatTracker" && app?.tabName !== "combat") return;
  patchCombatTracker(app, html, data, options);
});

Hooks.on("updateCombat", async (combat, changed) => {
  if (!isSra2World()) return;
  if (!game.user?.isGM) return;
  if (!game.settings.get(MODULE_ID, "resetOnNewRound")) return;
  if (!Object.prototype.hasOwnProperty.call(changed ?? {}, "round")) return;

  try {
    await clearRoundState(combat);
  } catch (error) {
    console.error(`${MODULE_ID} | Failed to reset combat round state`, error);
  }
});
