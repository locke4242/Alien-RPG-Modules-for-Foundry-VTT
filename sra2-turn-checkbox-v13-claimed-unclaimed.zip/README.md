# SRA2: Combat Turn Checkboxes

A small Foundry VTT v13 add-on module for the Shadowrun Anarchy 2 (`sra2`) system.

## Features

- Splits the Combat Encounters / Combat Tracker list into **Unclaimed** and **Claimed** sections.
- All combatants start each new round as **Unclaimed**.
- Clicking the hand icon on an Unclaimed combatant moves that combatant to **Claimed** and makes it Foundry's active turn.
- Clicking the hand icon on an already Claimed combatant makes it Foundry's active turn again.
- Adds a checkbox to each combatant row so the table can mark whether that combatant has taken their turn.
- Lets any connected player click any combatant row checkbox or hand button.
- Stores checkbox and claim state on the Combatant as module flags.
- Hides the per-combatant roll initiative button.
- Clears all checkboxes and claims automatically when the combat round changes by default.

## Player actions

Non-GM players usually cannot directly update Combat and Combatant documents. This module relays player checkbox and hand-button clicks through a hidden blind-whisper chat message to the active GM client. The GM client applies the actual Combat change, then the relay message is deleted so it does not clutter chat.

A GM user must be logged in for player clicks to update the encounter for everyone.

## Settings

- **Hide individual roll initiative buttons**: Enabled by default.
- **Reset turn state on new round**: Enabled by default. Clears checkboxes and moves every combatant back to Unclaimed.
- **Split combat tracker into Claimed and Unclaimed sections**: Enabled by default.

## Install layout

The ZIP is packaged with `module.json` at the root. After installation, the target folder should look like:

```text
Data/modules/sra2-turn-checkbox/module.json
Data/modules/sra2-turn-checkbox/scripts/main.mjs
Data/modules/sra2-turn-checkbox/styles/main.css
```

## Version 0.7.0

- Added Claimed and Unclaimed sections to the Combat Encounters list.
- Added a `slotClaimed` Combatant flag.
- Hand icon now claims an Unclaimed combatant and makes it Foundry's active turn.
- New rounds now reset both checkboxes and claimed state.
- Hand button remains clickable for the active combatant when that combatant is still Unclaimed, so it can be moved into Claimed.

## Version 0.6.0

- Replaced the player-action socket relay with a document-based GM relay.
- Player checkbox clicks and hand-button clicks now create a hidden GM relay message.
- The active GM client processes the relay, updates the Combat/Combatant document, and deletes the relay message.
