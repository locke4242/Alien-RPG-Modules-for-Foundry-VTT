export const MODULE_ID = "sra2-distances";
export const MODULE_TITLE = "SRA2 Distances";

export const PALETTES = {
    "default": {
        label: "Traffic Light",
        colors: {
            ring1: "#ff0000",
            ring2: "#ffa500",
            ring3: "#90ee90",
            ring4: "#00aaff"
        }
    },
    "option2": {
        label: "Inverse Traffic Light",
        colors: {
            ring1: "#90ee90",
            ring2: "#ffff00",
            ring3: "#ffa500",
            ring4: "#ff0000"
        }
    },
    "option3": {
        label: "Synthwave",
        colors: {
            ring1: "#ff00ff", // Magenta
            ring2: "#bd00ff", // Electric Purple
            ring3: "#00aaff", // Dodger Blue
            ring4: "#00ffff"  // Cyan
        }
    },
    "option4": {
        label: "True Fire",
        colors: {
            ring1: "#ff0000", // Pure Red
            ring2: "#ff4500", // Orange Red
            ring3: "#ffa500", // Orange
            ring4: "#ffcc00"  // Golden Yellow
        }
    }
};

export const DEFAULTS = {
    // Shadowrun Anarchy 2 range thresholds from the SRA2 roll dialog:
    // Close < 2m, Short 2-15m, Medium 16-60m, Long > 60m.
    // Long has no finite upper boundary, so the visual rings draw the three finite cutoffs
    // and hover labels report Long for anything beyond 60m.
    ranges: {
        ring1: { distance: 2,  label: "DHD.ranges.melee" },
        ring2: { distance: 15, label: "DHD.ranges.short" },
        ring3: { distance: 60, label: "DHD.ranges.medium" }
    },
    beyondLastRangeLabel: "DHD.ranges.long"
};
