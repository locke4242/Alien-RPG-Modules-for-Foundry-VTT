# SRA2: Distances

A patched Foundry VTT v13 module for the **Shadowrun Anarchy 2 (SRA2)** system. It displays SRA2 range-band guide rings around tokens and can show hover distance labels between a selected source token and other tokens on the scene.

This is adapted from `daggerheart-distances` for use with the `sra2` system.

## Range bands

The module uses the range thresholds present in the SRA2 system roll dialog:

- **Close:** under 2m
- **Short:** 2–15m
- **Medium:** 16–60m
- **Long:** beyond 60m

Because Long has no finite upper boundary, the module draws the three finite cutoff rings: 2m, 15m, and 60m. Hover labels report Long for targets beyond 60m.

## Main behavior

- Select a token to automatically show its SRA2 range rings.
- Deselect the token to remove selection-created rings.
- Press **R** or use the Token HUD button to manually toggle rings.
- GMs can use **Shift+R** to broadcast rings to all clients temporarily.
- Select multiple tokens and press **M** or run `DHDistances.MassMeasurement()` to measure from the group center.

## Settings

In Foundry’s module settings you can configure visual style, color palette, line thickness, fill style, highlighting, and whether rings appear automatically when a token is selected.

## Compatibility

- Foundry VTT: v13
- System: `sra2` / Shadowrun Anarchy 2

## Macro API

```js
DHDistances.Toggle();                 // Toggle rings for selected/hovered token
DHDistances.Toggle({ remote: true }); // GM: broadcast rings to all players
DHDistances.MassMeasurement();        // Rings from center of selected tokens
DHDistances.Toggle({ mode: '2d' });   // Ignore elevation
DHDistances.Toggle({ mode: '3d' });   // Account for elevation
DHDistances.Toggle({ mode: 'both' }); // Show both 3D and 2D distances
```

## Credits

Original module: `daggerheart-distances` by Mestre Digital / Bruno Calado, itself forked from `foundry_combat_distances`.
