# Changelog

## 0.2.0-sra2.2

- Renamed the first range band from Melee to Close.
- Changed the Close cutoff from 3m to 2m.

## 0.2.0-sra2.1

- Retargeted the module from Daggerheart to the SRA2 system.
- Set Foundry compatibility to v13.
- Changed the package id to `sra2-distances`.
- Updated package relationships and macro pack metadata for `sra2`.
- Removed the Daggerheart-only `CONFIG.DH` ready hook.
- Added automatic rings on token selection, enabled by default.
- Replaced Daggerheart range labels and thresholds with SRA2 thresholds:
  - Melee: 3m cutoff
  - Short: 15m cutoff
  - Medium: 60m cutoff
  - Long: beyond 60m, shown in hover labels rather than as an infinite ring
