# SRA2: Host Links

A Foundry VTT v13 add-on module for the Shadowrun Anarchy 2 (`sra2`) system.

This module adds persistent visual links between Host/server tokens on a Scene.

## Workflow

1. Log in as GM.
2. Place two or more SRA2 Host/server actors on a Scene.
3. Select a Host/server token.
4. Click the Host Link button in the token HUD.
5. Select another Host/server token to complete the link.
6. Optionally enter a label.
7. The module draws a persistent arrow between the two Host/server tokens.

Links are stored as Scene flags, so they persist with the Scene and redraw when tokens move or the Scene reloads.

## Features

- Targets SRA2 actor type `server`; also supports `host` if present.
- Adds a token HUD control to start a Host link.
- Adds a token HUD control to clear all links attached to a Host token.
- Draws arrows between linked Host tokens on the canvas.
- Optional labels appear near the middle of a link.
- Links automatically redraw when linked tokens move.
- Broken links are skipped if one of the linked tokens no longer exists.
- Players can see links; link editing is GM-only.

## Install layout

The ZIP is packaged with `module.json` at the root. After installation, the target folder should look like:

```text
Data/modules/sra2-host-links/module.json
Data/modules/sra2-host-links/scripts/main.mjs
Data/modules/sra2-host-links/styles/main.css
```

## Version 0.1.0

Initial release.


## Version 0.2.0

- Host links are hidden whenever either connected Host/server token has its token visibility set to hidden.
- Links automatically reappear when both connected tokens are visible again.
