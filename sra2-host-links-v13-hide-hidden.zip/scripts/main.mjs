const MODULE_ID = "sra2-host-links";
const FLAG_LINKS = "links";

let pendingLinkSourceTokenId = null;
let hostLinkLayer = null;

function isSra2World() {
  return game?.system?.id === "sra2";
}

function htmlElementFromRenderHook(html) {
  if (html instanceof HTMLElement) return html;
  if (html?.[0] instanceof HTMLElement) return html[0];
  if (html?.element instanceof HTMLElement) return html.element;
  return null;
}

function getTokenFromHud(app) {
  return app?.object ?? app?.token ?? null;
}

function getActorType(tokenOrDocument) {
  const token = tokenOrDocument?.object ?? tokenOrDocument;
  const actor = token?.actor ?? token?.document?.actor ?? tokenOrDocument?.actor;
  return actor?.type ?? null;
}

function isHostToken(tokenOrDocument) {
  const type = getActorType(tokenOrDocument);
  return type === "server" || type === "host";
}

function getCurrentSceneLinks(scene = canvas?.scene) {
  const links = scene?.getFlag?.(MODULE_ID, FLAG_LINKS);
  return Array.isArray(links) ? foundry.utils.deepClone(links) : [];
}

async function setCurrentSceneLinks(links, scene = canvas?.scene) {
  if (!scene) return;
  await scene.setFlag(MODULE_ID, FLAG_LINKS, links);
}

function randomId() {
  return foundry?.utils?.randomID?.() ?? crypto.randomUUID?.() ?? `${Date.now()}-${Math.random()}`;
}

function getCanvasToken(tokenId) {
  if (!tokenId || !canvas?.tokens) return null;
  return canvas.tokens.get?.(tokenId) ?? canvas.tokens.placeables?.find((token) => token.id === tokenId || token.document?.id === tokenId) ?? null;
}

function getTokenDisplayName(token) {
  return token?.document?.name ?? token?.actor?.name ?? token?.name ?? "Host";
}

function isTokenHidden(tokenOrDocument) {
  const doc = tokenOrDocument?.document ?? tokenOrDocument;
  return doc?.hidden === true;
}

function linkEndpointsAreVisible(fromToken, toToken) {
  return !isTokenHidden(fromToken) && !isTokenHidden(toToken);
}

function getTokenCenter(token) {
  if (token?.center) return { x: token.center.x, y: token.center.y };

  const doc = token?.document ?? token;
  const gridSize = canvas?.grid?.size ?? 100;
  const width = token?.w ?? ((doc?.width ?? 1) * gridSize);
  const height = token?.h ?? ((doc?.height ?? 1) * gridSize);

  return {
    x: (doc?.x ?? 0) + width / 2,
    y: (doc?.y ?? 0) + height / 2
  };
}

function getTokenRadius(token) {
  const doc = token?.document ?? token;
  const gridSize = canvas?.grid?.size ?? 100;
  const width = token?.w ?? ((doc?.width ?? 1) * gridSize);
  const height = token?.h ?? ((doc?.height ?? 1) * gridSize);
  return Math.max(12, Math.min(width, height) * 0.36);
}

function colorStringToHex(colorString) {
  if (typeof colorString !== "string") return 0x00d8ff;
  const normalized = colorString.trim().replace(/^#/, "");
  const parsed = Number.parseInt(normalized, 16);
  return Number.isFinite(parsed) ? parsed : 0x00d8ff;
}

function getLineColor() {
  return colorStringToHex(game.settings.get(MODULE_ID, "lineColor"));
}

function getLineWidth() {
  const value = Number(game.settings.get(MODULE_ID, "lineWidth"));
  return Number.isFinite(value) && value > 0 ? value : 4;
}

function getArrowSize() {
  const value = Number(game.settings.get(MODULE_ID, "arrowSize"));
  return Number.isFinite(value) && value > 0 ? value : 22;
}

function removeHostLinkLayer() {
  if (!hostLinkLayer) return;
  try {
    hostLinkLayer.destroy({ children: true });
  } catch (error) {
    console.warn(`${MODULE_ID} | Failed to destroy old Host Link layer`, error);
  }
  hostLinkLayer = null;
}

function makePixiText(text, style) {
  try {
    return new PIXI.Text(text, style);
  } catch (_error) {
    return new PIXI.Text({ text, style });
  }
}

function drawArrow(container, fromToken, toToken, link) {
  const fromCenter = getTokenCenter(fromToken);
  const toCenter = getTokenCenter(toToken);
  const dx = toCenter.x - fromCenter.x;
  const dy = toCenter.y - fromCenter.y;
  const distance = Math.hypot(dx, dy);

  if (!Number.isFinite(distance) || distance < 8) return;

  const ux = dx / distance;
  const uy = dy / distance;
  const fromRadius = getTokenRadius(fromToken);
  const toRadius = getTokenRadius(toToken);

  const start = {
    x: fromCenter.x + ux * fromRadius,
    y: fromCenter.y + uy * fromRadius
  };
  const end = {
    x: toCenter.x - ux * toRadius,
    y: toCenter.y - uy * toRadius
  };

  const color = getLineColor();
  const lineWidth = getLineWidth();
  const arrowSize = getArrowSize();
  const normalX = -uy;
  const normalY = ux;

  const glow = new PIXI.Graphics();
  glow.lineStyle(lineWidth + 5, color, 0.20);
  glow.moveTo(start.x, start.y);
  glow.lineTo(end.x, end.y);
  container.addChild(glow);

  const graphics = new PIXI.Graphics();
  graphics.lineStyle(lineWidth, color, 0.88);
  graphics.moveTo(start.x, start.y);
  graphics.lineTo(end.x, end.y);

  graphics.beginFill(color, 0.92);
  graphics.moveTo(end.x, end.y);
  graphics.lineTo(
    end.x - ux * arrowSize + normalX * arrowSize * 0.42,
    end.y - uy * arrowSize + normalY * arrowSize * 0.42
  );
  graphics.lineTo(
    end.x - ux * arrowSize - normalX * arrowSize * 0.42,
    end.y - uy * arrowSize - normalY * arrowSize * 0.42
  );
  graphics.lineTo(end.x, end.y);
  graphics.endFill();
  container.addChild(graphics);

  if (game.settings.get(MODULE_ID, "showLabels") && link.label) {
    const label = makePixiText(link.label, {
      fontFamily: "Signika, sans-serif",
      fontSize: Math.max(14, Math.min(28, (canvas?.grid?.size ?? 100) * 0.18)),
      fill: color,
      stroke: 0x000000,
      strokeThickness: 5,
      align: "center"
    });
    label.anchor?.set?.(0.5);
    label.x = (start.x + end.x) / 2;
    label.y = (start.y + end.y) / 2 - 10;
    container.addChild(label);
  }
}

function refreshHostLinks() {
  if (!isSra2World() || !canvas?.ready || !canvas?.scene || !canvas?.stage || !globalThis.PIXI) return;

  removeHostLinkLayer();

  const links = getCurrentSceneLinks(canvas.scene);
  if (!links.length) return;

  hostLinkLayer = new PIXI.Container();
  hostLinkLayer.name = MODULE_ID;
  hostLinkLayer.sortableChildren = true;
  hostLinkLayer.zIndex = 50_000;
  hostLinkLayer.eventMode = "none";

  try {
    canvas.stage.sortableChildren = true;
    canvas.stage.addChild(hostLinkLayer);
  } catch (error) {
    console.warn(`${MODULE_ID} | Failed to add Host Link layer to canvas`, error);
    hostLinkLayer = null;
    return;
  }

  for (const link of links) {
    const fromToken = getCanvasToken(link.fromTokenId);
    const toToken = getCanvasToken(link.toTokenId);
    if (!fromToken || !toToken) continue;
    if (!linkEndpointsAreVisible(fromToken, toToken)) continue;
    drawArrow(hostLinkLayer, fromToken, toToken, link);
  }
}

function linksMatchExisting(links, fromTokenId, toTokenId) {
  return links.some((link) => {
    const sameDirection = link.fromTokenId === fromTokenId && link.toTokenId === toTokenId;
    const reverseDirection = link.fromTokenId === toTokenId && link.toTokenId === fromTokenId;
    return sameDirection || reverseDirection;
  });
}

async function promptForLabel(fromToken, toToken) {
  if (!game.settings.get(MODULE_ID, "promptForLabel")) return "";

  const title = "Label Host Link";
  const fromName = getTokenDisplayName(fromToken);
  const toName = getTokenDisplayName(toToken);
  const content = `
    <form class="sra2hl-label-dialog">
      <p>Optional label for the Host link from <strong>${foundry.utils.escapeHTML(fromName)}</strong> to <strong>${foundry.utils.escapeHTML(toName)}</strong>.</p>
      <div class="form-group">
        <label>Label</label>
        <input type="text" name="label" placeholder="Backdoor, WAN, Slave, Patrol Route..." autofocus />
      </div>
    </form>`;

  if (globalThis.Dialog?.prompt) {
    return Dialog.prompt({
      title,
      content,
      label: "Create Link",
      callback: (html) => {
        const root = htmlElementFromRenderHook(html) ?? html;
        return root?.querySelector?.("input[name='label']")?.value?.trim?.() ?? "";
      },
      rejectClose: false
    });
  }

  return window.prompt(`${title}: ${fromName} → ${toName}`, "")?.trim?.() ?? "";
}

async function createHostLink(fromToken, toToken) {
  if (!game.user?.isGM) {
    ui.notifications?.warn?.("Only the GM can create Host links.");
    return;
  }

  if (!canvas?.scene) return;
  if (!fromToken || !toToken || fromToken.id === toToken.id) return;
  if (!isHostToken(fromToken) || !isHostToken(toToken)) {
    ui.notifications?.warn?.("Host links can only be created between Host/server tokens.");
    return;
  }

  const links = getCurrentSceneLinks(canvas.scene);
  if (linksMatchExisting(links, fromToken.id, toToken.id)) {
    ui.notifications?.warn?.("Those Host tokens are already linked on this Scene.");
    return;
  }

  const label = await promptForLabel(fromToken, toToken);
  links.push({
    id: randomId(),
    fromTokenId: fromToken.id,
    toTokenId: toToken.id,
    label: label ?? "",
    createdBy: game.user?.id ?? null,
    createdTime: Date.now()
  });

  await setCurrentSceneLinks(links, canvas.scene);
  refreshHostLinks();
}

async function clearLinksForToken(token) {
  if (!game.user?.isGM || !canvas?.scene || !token) return;
  const links = getCurrentSceneLinks(canvas.scene);
  const remaining = links.filter((link) => link.fromTokenId !== token.id && link.toTokenId !== token.id);
  const removed = links.length - remaining.length;

  if (!removed) {
    ui.notifications?.info?.("This Host token has no Host links to clear.");
    return;
  }

  let confirmed = true;
  const message = `Remove ${removed} Host link${removed === 1 ? "" : "s"} connected to ${getTokenDisplayName(token)}?`;
  if (globalThis.Dialog?.confirm) {
    confirmed = await Dialog.confirm({
      title: "Clear Host Links",
      content: `<p>${foundry.utils.escapeHTML(message)}</p>`,
      yes: () => true,
      no: () => false,
      defaultYes: false
    });
  } else {
    confirmed = window.confirm(message);
  }

  if (!confirmed) return;
  await setCurrentSceneLinks(remaining, canvas.scene);
  refreshHostLinks();
}

function startHostLink(token) {
  if (!game.user?.isGM) {
    ui.notifications?.warn?.("Only the GM can create Host links.");
    return;
  }
  if (!isHostToken(token)) {
    ui.notifications?.warn?.("Select a Host/server token to start a Host link.");
    return;
  }

  pendingLinkSourceTokenId = token.id;
  ui.notifications?.info?.(`Host link started from ${getTokenDisplayName(token)}. Select another Host/server token to complete it.`);
}

function addHudControl(root, className, title, iconClass, onClick) {
  if (!root || root.querySelector(`.${className}`)) return;

  const control = document.createElement("div");
  control.className = `control-icon ${className} sra2hl-hud-control`;
  control.title = title;
  control.setAttribute("role", "button");
  control.setAttribute("tabindex", "0");
  control.innerHTML = `<i class="${iconClass}"></i>`;

  const stopOnly = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };
  const activate = (event) => {
    stopOnly(event);
    onClick(event);
  };
  control.addEventListener("click", activate);
  control.addEventListener("pointerdown", stopOnly);
  control.addEventListener("mousedown", stopOnly);
  control.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") activate(event);
  });

  const column = root.querySelector(".col.right") ?? root.querySelector(".right") ?? root;
  column.appendChild(control);
}

function onRenderTokenHud(app, html) {
  if (!isSra2World() || !game.user?.isGM) return;

  const token = getTokenFromHud(app);
  if (!token || !isHostToken(token)) return;

  const root = htmlElementFromRenderHook(html);
  if (!root) return;

  addHudControl(
    root,
    "sra2hl-start-host-link",
    "Start Host Link",
    "fas fa-project-diagram",
    () => startHostLink(token)
  );

  addHudControl(
    root,
    "sra2hl-clear-host-links",
    "Clear Host Links for this Host",
    "fas fa-unlink",
    () => clearLinksForToken(token)
  );
}

async function onControlToken(token, controlled) {
  if (!isSra2World() || !game.user?.isGM || !controlled || !pendingLinkSourceTokenId) return;
  if (!token || token.id === pendingLinkSourceTokenId) return;

  const fromToken = getCanvasToken(pendingLinkSourceTokenId);
  if (!fromToken) {
    pendingLinkSourceTokenId = null;
    ui.notifications?.warn?.("The original Host token could not be found. Start the Host link again.");
    return;
  }

  if (!isHostToken(token)) {
    ui.notifications?.warn?.("Select another Host/server token to complete the Host link.");
    return;
  }

  const toToken = token;
  pendingLinkSourceTokenId = null;
  await createHostLink(fromToken, toToken);
}

function registerSettings() {
  game.settings.register(MODULE_ID, "lineColor", {
    name: "Host link color",
    hint: "Hex color used for Host link arrows.",
    scope: "world",
    config: true,
    type: String,
    default: "#00d8ff",
    onChange: refreshHostLinks
  });

  game.settings.register(MODULE_ID, "lineWidth", {
    name: "Host link width",
    hint: "Canvas line width used for Host link arrows.",
    scope: "world",
    config: true,
    type: Number,
    default: 4,
    range: { min: 1, max: 12, step: 1 },
    onChange: refreshHostLinks
  });

  game.settings.register(MODULE_ID, "arrowSize", {
    name: "Host link arrow size",
    hint: "Canvas arrowhead size used for Host link arrows.",
    scope: "world",
    config: true,
    type: Number,
    default: 22,
    range: { min: 8, max: 64, step: 1 },
    onChange: refreshHostLinks
  });

  game.settings.register(MODULE_ID, "showLabels", {
    name: "Show Host link labels",
    hint: "Display optional labels on Host links.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
    onChange: refreshHostLinks
  });

  game.settings.register(MODULE_ID, "promptForLabel", {
    name: "Prompt for link labels",
    hint: "Ask for an optional label whenever a new Host link is created.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });
}

Hooks.once("init", () => {
  registerSettings();
});

Hooks.once("ready", () => {
  if (!isSra2World()) return;
  game.modules.get(MODULE_ID).api = {
    refresh: refreshHostLinks,
    clearSceneLinks: async () => {
      if (!game.user?.isGM || !canvas?.scene) return;
      await setCurrentSceneLinks([], canvas.scene);
      refreshHostLinks();
    },
    getLinks: () => getCurrentSceneLinks(canvas?.scene)
  };
});

Hooks.on("renderTokenHUD", onRenderTokenHud);
Hooks.on("controlToken", onControlToken);

Hooks.on("canvasReady", refreshHostLinks);
Hooks.on("canvasPan", refreshHostLinks);
Hooks.on("updateScene", (scene) => {
  if (scene?.id === canvas?.scene?.id) refreshHostLinks();
});
Hooks.on("createToken", (tokenDocument) => {
  if (tokenDocument?.parent?.id === canvas?.scene?.id) refreshHostLinks();
});
Hooks.on("updateToken", (tokenDocument) => {
  if (tokenDocument?.parent?.id === canvas?.scene?.id) refreshHostLinks();
});
Hooks.on("deleteToken", async (tokenDocument) => {
  if (tokenDocument?.parent?.id !== canvas?.scene?.id) return;

  if (game.user?.isGM && canvas?.scene) {
    const links = getCurrentSceneLinks(canvas.scene);
    const remaining = links.filter((link) => link.fromTokenId !== tokenDocument.id && link.toTokenId !== tokenDocument.id);
    if (remaining.length !== links.length) await setCurrentSceneLinks(remaining, canvas.scene);
  }

  refreshHostLinks();
});
Hooks.on("canvasTearDown", () => {
  pendingLinkSourceTokenId = null;
  removeHostLinkLayer();
});
